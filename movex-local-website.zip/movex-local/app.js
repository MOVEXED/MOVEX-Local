const STORAGE_KEY = "movexLocalDemoJobsV1";
const seedJobs = [
 {id:"MOV-2026-00001",from:"Birmingham City Centre",to:"Jewellery Quarter",customer:"City Gifts",status:"Delivered",driver:"Alex Morgan",time:"09:15",parcel:"Retail package (demo)"},
 {id:"MOV-2026-00002",from:"New Street",to:"Digbeth",customer:"Urban Retail",status:"In transit",driver:"Alex Morgan",time:"10:30",parcel:"Small parcel (demo)"},
 {id:"MOV-2026-00003",from:"The Mailbox",to:"Edgbaston",customer:"Mailbox Florist",status:"Awaiting collection",driver:"Alex Morgan",time:"11:45",parcel:"Small parcel (demo)"},
 {id:"MOV-2026-00004",from:"Colmore Row",to:"Aston",customer:"Office Supplies Co.",status:"Awaiting collection",driver:"Unassigned",time:"12:30",parcel:"Documents (demo)"},
 {id:"MOV-2026-00005",from:"Bullring",to:"Moseley",customer:"Birmingham Boutique",status:"Awaiting collection",driver:"Unassigned",time:"13:00",parcel:"Retail package (demo)"}
];
let jobs = loadJobs();

function loadJobs(){try{const saved=localStorage.getItem(STORAGE_KEY);return saved?JSON.parse(saved):structuredClone(seedJobs)}catch(e){return structuredClone(seedJobs)}}
function saveJobs(){localStorage.setItem(STORAGE_KEY,JSON.stringify(jobs))}
function esc(value){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function statusClass(status){return status==="Delivered"?"delivered":status==="In transit"?"transit":"waiting"}
function badge(status){return `<span class="pill ${statusClass(status)}">${esc(status)}</span>`}
function stat(label,value,sub=""){return `<div class="stat-card"><div class="stat-value">${value}</div><div class="stat-label">${label}${sub?` · ${sub}`:""}</div></div>`}
function renderStats(){
 const delivered=jobs.filter(j=>j.status==="Delivered").length,transit=jobs.filter(j=>j.status==="In transit").length,waiting=jobs.filter(j=>j.status==="Awaiting collection").length;
 document.querySelector("#driverStats").innerHTML=[stat("Assigned to Alex",jobs.filter(j=>j.driver==="Alex Morgan").length),stat("Completed",delivered),stat("In transit",transit),stat("Awaiting collection",waiting)].join("");
 document.querySelector("#managementStats").innerHTML=[stat("Total bookings",jobs.length),stat("Delivered",delivered),stat("In transit",transit),stat("Awaiting collection",waiting)].join("");
}
function renderDriver(){
 const mine=jobs.filter(j=>j.driver==="Alex Morgan");
 document.querySelector("#driverJobs").innerHTML=mine.length?mine.map(j=>`<article class="job-card"><div><div class="job-id">${esc(j.id)}</div><div class="job-route">${esc(j.from)} <span style="color:var(--red)">→</span> ${esc(j.to)}</div><div class="job-meta">${esc(j.customer)} · ${esc(j.time)}</div></div><div class="job-actions">${badge(j.status)}${j.status==="Awaiting collection"?`<button class="button primary small" data-action="collect" data-id="${esc(j.id)}">Mark collected</button>`:j.status==="In transit"?`<button class="button primary small" data-action="deliver" data-id="${esc(j.id)}">Confirm delivery</button>`:""}</div></article>`).join(""):`<p class="job-meta">No jobs currently assigned to this demo driver.</p>`;
}
function renderManagement(){
 document.querySelector("#managementJobs").innerHTML=jobs.map(j=>`<article class="job-card"><div><div class="job-id">${esc(j.id)}</div><div class="job-route">${esc(j.from)} <span style="color:var(--red)">→</span> ${esc(j.to)}</div><div class="job-meta">${esc(j.customer)} · ${esc(j.parcel)}</div><div class="job-meta">Driver: ${esc(j.driver)}</div></div><div class="job-actions">${badge(j.status)}<select aria-label="Assign driver for ${esc(j.id)}" data-assign="${esc(j.id)}"><option value="Unassigned" ${j.driver==="Unassigned"?"selected":""}>Unassigned</option><option value="Alex Morgan" ${j.driver==="Alex Morgan"?"selected":""}>Alex Morgan</option></select></div></article>`).join("");
}
function renderAll(){renderStats();renderDriver();renderManagement();if(document.querySelector("#trackingRef"))renderTracking(document.querySelector("#trackingRef").value)}
function updateJob(id,changes){jobs=jobs.map(j=>j.id===id?{...j,...changes}:j);saveJobs();renderAll()}
function renderTracking(reference){
 const box=document.querySelector("#trackingResult");if(!box)return;
 const job=jobs.find(j=>j.id.toLowerCase()===String(reference||"").trim().toLowerCase());
 if(!job){box.innerHTML=`<h2>We couldn't find that reference</h2><p class="job-meta">Check the reference and try again. Demo references start with MOV-2026-.</p>`;return}
 const stages=["Booking received","Collected","In transit","Delivered"];
 const current=job.status==="Awaiting collection"?0:job.status==="In transit"?2:3;
 const lines=stages.map((s,i)=>`<li class="${i<=current?"done":""}"><strong>${s}</strong><span>${i===0?"Demo booking registered":i===1?(current>=1?"Collection recorded":"Waiting for collection"):i===2?(current>=2?"Parcel marked as in transit":"Not yet reached this stage"):(current>=3?"Delivery marked complete":"Awaiting delivery confirmation")}</span></li>`).join("");
 box.innerHTML=`<div class="panel-heading"><div><p class="eyebrow">TRACKING RESULT</p><h2>${esc(job.id)}</h2><p>${esc(job.customer)}</p></div>${badge(job.status)}</div><p class="job-route">${esc(job.from)} <span style="color:var(--red)">→</span> ${esc(job.to)}</p><p class="job-meta">${esc(job.parcel)} · Assigned: ${esc(job.driver)}</p><ul class="timeline">${lines}</ul>`;
}
document.querySelector("#driverJobs").addEventListener("click",e=>{const b=e.target.closest("button[data-action]");if(!b)return;const j=jobs.find(x=>x.id===b.dataset.id);if(!j)return;if(b.dataset.action==="collect")updateJob(j.id,{status:"In transit"});if(b.dataset.action==="deliver")updateJob(j.id,{status:"Delivered"})});
document.querySelector("#managementJobs").addEventListener("change",e=>{if(!e.target.matches("[data-assign]"))return;updateJob(e.target.dataset.assign,{driver:e.target.value})});
document.querySelector("#trackingForm").addEventListener("submit",e=>{e.preventDefault();renderTracking(document.querySelector("#trackingRef").value)});
document.querySelector("#trackingRef").addEventListener("input",e=>renderTracking(e.target.value));
document.querySelector("#bookingForm").addEventListener("submit",e=>{
 e.preventDefault();
 const n=jobs.length+1,id=`MOV-2026-${String(n).padStart(5,"0")}`;
 const job={id,from:document.querySelector("#collection").value,to:document.querySelector("#destination").value,customer:document.querySelector("#businessName").value.trim(),status:"Awaiting collection",driver:"Unassigned",time:"New demo booking",parcel:document.querySelector("#parcelType").value};
 jobs.push(job);saveJobs();renderAll();
 document.querySelector("#bookingMessage").textContent=`Demo booking created. Tracking reference: ${id}`;
 document.querySelector("#trackingRef").value=id;
});
document.querySelector("#resetDemo").addEventListener("click",()=>{if(confirm("Reset all demonstration bookings and statuses on this browser?")){jobs=structuredClone(seedJobs);saveJobs();renderAll()}});
const menuToggle=document.querySelector("#menuToggle"),mainNav=document.querySelector("#mainNav");
menuToggle.addEventListener("click",()=>{const open=mainNav.classList.toggle("open");menuToggle.setAttribute("aria-expanded",String(open))});
function showView(){const id=location.hash.slice(1)||"home";document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active-view",v.id===id));document.querySelectorAll(".nav-link").forEach(a=>a.classList.toggle("active",a.dataset.view===id));mainNav.classList.remove("open");menuToggle.setAttribute("aria-expanded","false");if(id==="track")renderTracking(document.querySelector("#trackingRef").value)}
window.addEventListener("hashchange",showView);showView();renderAll();
