# MOVEX Local — Website Prototype

A responsive, front-end demonstration website for the MOVEX Local courier concept.

## Included features

- Home page and portal navigation
- Driver dashboard with fictional jobs and status updates
- Management dashboard with job assignment
- Customer demo booking form
- Tracking reference lookup and parcel timeline
- Schematic Birmingham-area map illustration
- Responsive layout for mobile and desktop
- Demo job changes saved in the browser's local storage

## Run it locally

1. Download and extract `movex-local-website.zip`.
2. Open the `movex-local` folder.
3. Double-click `index.html` to open it in a modern browser.

For best results, you can also run a simple local web server from this folder:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Publish free with GitHub Pages

1. Create a GitHub account in your own name, with help from a parent or guardian if needed.
2. Create a new **public** repository, for example `movex-local`.
3. Upload `index.html`, `styles.css`, `app.js`, and this README to the repository root.
4. Open **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**.
6. Choose the `main` branch and `/ (root)` folder, then save.
7. GitHub will provide a public website address after publishing.

GitHub's account terms, age rules and any applicable parental-consent requirements should be checked with a parent or guardian before signing up. A public repository means the source code is visible to everyone.

## Important limitations

This is a prototype, not a production courier platform.

- There is no server or central database. Demo data is stored in the browser's local storage on each device.
- Different visitors/devices do not share bookings or updates.
- There is no secure login, user roles, payment processing, email/SMS notifications, real GPS, live mapping or verified proof of delivery.
- The Birmingham map is illustrative only and is not suitable for navigation.
- Do not enter real customer names, phone numbers, addresses, parcel details, passwords or other personal information.
- Do not accept live bookings or use this prototype to coordinate real deliveries.

Before real-world use, MOVEX would need a properly designed backend, secure authentication and access controls, privacy notices and data-protection processes, security testing, backups, operational procedures, appropriate insurance and legal checks. As the founder is 15, involve a parent/guardian and check the applicable child-employment and business rules before undertaking any work or trading.

## Project files

- `index.html` — page structure and content
- `styles.css` — visual design and responsive layout
- `app.js` — demo data and interactive behaviour
- `README.md` — setup and publishing guide
